# PyGame: Mario 0.2
# Камера перемещается вместе с игроком.

import os
import sys
import numpy as np
import pygame as pg
from pygame import time


def load_image(name):
    """Функция загрузки изображения из файла"""
    filename = os.path.join('data', name)
    try:
        image = pg.image.load(filename)
    except pg.error as error:
        print('Не могу загрузить изображение:', name)
        raise SystemExit(error)
    return image


class Player(pg.sprite.Sprite):
    """Игрок"""
    def __init__(self, pos_x, pos_y):
        super().__init__(player_group)
        self.image = player_image
        self.pos = (pos_x, pos_y)
        self.rect = self.image.get_rect().move(tile_width * pos_x + 15,
                                               tile_height * pos_y + 5)

    # Адаптируем функцию move() для работы с камерой:
    def move(self, x, y):
        """
        Функция перемещения.
        Перерисовываем игровое поле таким образом,
        чтобы оно менялось в зависимости от положения камеры.
        """
        # Обращаемся к объекту camera,
        # меняя её координаты относительно исходной точки игрока.
        # При этом координаты камеры привязаны к текущим координатам игрока:
        camera.dx -= tile_width * (x - self.pos[0])
        camera.dy -= tile_height * (y - self.pos[1])
        # Меняем координаты игрока:
        self.pos = (x, y)
        # Применяем перемещение всех тайлов относительно камеры:
        for sprite in tiles_group:
            camera.apply(sprite)


class Tile(pg.sprite.Sprite):
    """Тайл"""
    def __init__(self, tile_type, pos_x, pos_y):
        super().__init__(tiles_group)
        self.image = tile_images[tile_type]
        self.rect = self.image.get_rect().move(tile_width * pos_x,
                                               tile_height * pos_y)
        # Абсолютные координаты тайла на игровом поле.
        # Начало координат в левом верхнем углу.
        self.abs_pos = (self.rect.x, self.rect.y)


class Camera:
    """Камера"""
    def __init__(self):
        # Внутри класса Camera начало координат
        # инициализируется как (0, 0) один раз
        # при создании объекта camera в основной программе:
        self.dx, self.dy = 0, 0

    def apply(self, obj):
        """
        Функция перемещения тайла
        на величину перемещения камеры:
        """
        obj.rect.x = obj.abs_pos[0] + self.dx
        obj.rect.y = obj.abs_pos[1] + self.dy

    def update(self):
        # Начало координат камеры.
        # Вызывается в основной программе только один раз,
        # перед основным игровым циклом:
        self.dx, self.dy = 0, 0


def start_screen():

    start_screen_background = load_image('fon.jpg')
    screen.blit(start_screen_background, (0, 0))
    while True:
        for event in pg.event.get():
            if event.type == pg.QUIT:
                terminate()
            elif event.type == pg.KEYDOWN or event.type == pg.MOUSEBUTTONDOWN:
                return
        pg.display.flip()


def load_level(filename):
    """Функция загрузки уровня"""
    filename = os.path.join('data', filename)
    with open(filename, 'r') as mapfile:
        levelmap = np.array([list(i) for i in [line.strip() for line in mapfile]])
    return levelmap


def generate_level(level):
    player, x, y = None, None, None
    row, col = level.shape
    for y in range(row):
        for x in range(col):
            if level[y, x] == '.':
                Tile('empty', x, y)
            elif level[y, x] == '#':
                Tile('wall', x, y)
            elif level[y, x] == '@':
                Tile('empty', x, y)
                level[y, x] = '.'
                player = Player(x, y)
    return player, x, y


def move_player(player, movement):
    """Передвижение персонажа"""
    x, y = player.pos
    if movement == 'up':
        if y > 0 and levelmap[y - 1, x] == '.':
            player.move(x, y - 1)
    elif movement == 'down':
        if y < level_y - 1 and levelmap[y + 1, x] == '.':
            player.move(x, y + 1)
    elif movement == 'left':
        if x > 0 and levelmap[y, x - 1] == '.':
            player.move(x - 1, y)
    elif movement == 'right':
        if x < level_x - 1 and levelmap[y, x + 1] == '.':
            player.move(x + 1, y)


def terminate():
    """Выход из игры"""
    pg.quit()
    sys.exit()


if __name__ == '__main__':
    pg.init()
    pg.display.set_caption('Перемещение героя. Камера')
    size = width, height = 1280, 720
    screen = pg.display.set_mode(size)
    player_image = load_image('zomb.png')
    tile_images = {
        'wall': load_image('road.png'),
        'empty': load_image('sky3.jpg')
    }
    tile_width = tile_height = 80
    player_group = pg.sprite.Group()
    tiles_group = pg.sprite.Group()
    start_screen()

    # Создаём камеру:
    camera = Camera()

    levelmap = load_level('level-01.map')
    player, level_x, level_y = generate_level(levelmap)

    # Автоповтор нажатия клавиш
    # set_repeat(delay, interval)
    pg.key.set_repeat(200, 70)

    # Обновляем состояние камеры перед игровым циклом:
    camera.update()

    # Главный игровой цикл:
    fps = 60
    running = True
    while running:
        for event in pg.event.get():
            if event.type == pg.QUIT:
                running = False
            elif event.type == pg.KEYDOWN:
                if event.key == pg.K_UP:
                    move_player(player, 'up')
                elif event.key == pg.K_DOWN:
                    move_player(player, 'down')
                elif event.key == pg.K_LEFT:
                    move_player(player, 'left')
                elif event.key == pg.K_RIGHT:
                    move_player(player, 'right')
        screen.fill(pg.Color('black'))
        tiles_group.draw(screen)
        player_group.draw(screen)
        pg.display.flip()
        time.Clock().tick(fps)
    terminate()
