from yandex_testing_lesson import is_palindrome(data)


def test_is_palindrome():
    test_data = (
        (42, None),
        (['a', 'b', 'c'], None),
        ('', ''),
        ('aba', 'aba'),
        ('a', 'a'),
        ('abc', 'cba'),
    )
    for input_str, correct_output_str in test_data:
        try:
            current_output_str = is_palindrome(input_str)
        except TypeError:
            if correct_output_str is None:
                continue
            if type(input_str) == str:
                print('No')
                return False
        except Exception:
            print('No')
            return False
        else:
            if current_output_str != correct_output_str:
                print('\nОшибка!!!')
                print(f'reverse({input_str}) равно {current_output_str}'
                      f' вместо {correct_output_str}')
                return False
        print('Yes')
        return True


if __name__ == '__main__':
    test_is_palindrome()